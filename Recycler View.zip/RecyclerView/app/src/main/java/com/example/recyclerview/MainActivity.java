package com.example.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //a layout_products to store all the products
    List<Product> productList;

    //the recyclerview
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //getting the recyclerview from xml
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));

        //initializing the productlist
        productList = new ArrayList<>();


        //adding some items to our layout_products
        productList.add(
                new Product(
                        1,
                        "Item Name",
                        6,
                        R.drawable.bulletproof));

        productList.add(
                new Product(
                        1,
                        "Bell Peppers with Chicken Thigh",

                        60,
                        R.drawable.flower));

        productList.add(
                new Product(
                        1,
                        "Chicken Salad with Fries and Pies",

                        6,
                        R.drawable.greenday));

        productList.add(
                new Product(
                        1,
                        "Mango Juice with Avocado sauce",

                        60000,
                        R.drawable.greenday));

        productList.add(
                new Product(
                        1,
                        "Beef Patties with Thai Sweet Sauce",

                        6,
                        R.drawable.greenday));

        productList.add(
                new Product(
                        1,
                        "Happy Meal",

                        6,
                        R.drawable.greenday));
        productList.add(
                new Product(
                        1,
                        "Spicy Chicken",

                        6,
                        R.drawable.greenday));

        //creating recyclerview adapter
        ProductAdapter adapter = new ProductAdapter(this, productList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }
}