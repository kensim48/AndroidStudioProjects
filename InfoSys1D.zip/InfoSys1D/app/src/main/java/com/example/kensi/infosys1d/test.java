package com.example.kensi.infosys1d;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.simple.parser.JSONParser;

public class test {
    public static void main(String[] args) throws Exception {
        System.out.println(CheckoutRequest.login());
    }
}
